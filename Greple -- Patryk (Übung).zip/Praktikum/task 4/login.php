<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="de-DE">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="stylelogin.css">
<title>greple AI</title>
</head>
<body>

<header class="header" id="header">
    <a href="https://greple.de/">
	    <img class="one" src="greple.png" alt="Greple GMBH" style="width:180px;height:100px;"> 
    </a>
</header>

<section class="h1">
  <p class="br"><br></p>
  <h2>Please login...</h2>

  <button class="loginone" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Login</button>
  
  <div id="id01" class="modal">
    
    <form class="modal-content animate" action="/action_page.php" method="post">
        <div class="imgcontainer">
        <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
        <img src="profile.png" alt="Avatar" class="avatar">
         </div>
  
         <form method="post" action="login.php">
    	<?php include('errors.php'); ?>
    	<div class="container" class="container">
  	    	<label for="uname"><b>Username</b></label>
  		    <input type="text" name="username" placeholder="Enter Username">
  	    </div>
  	    <div class="container">
  		    <label>Password</label>
  		    <input type="password" name="psw" placeholder="Enter Password">
  	    </div>
    	<div>
              <button type="submit" class="login" name="login_user">Login</button>
              <button class="register" type="submit" href="register.php">Register</button>
    	</div>
    </form>
  
      <div class="container" style="background-color:#f1f1f1">
        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <span class="psw">Forgot my <a href="#"><b>password.</b></a></span>
      </div>
    </form>
  </div>
  
  <script>
  // Get the modal
  var modal = document.getElementById('id01');
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }
  </script>

  <div class="backgroundtwo">
    <img class="backgroundtwo" src="backgroundtwo.png" alt="Greple GMBH">
  </div>
</section>

<footer>
	<div class="footer">
		<div class="footertext">
		<p class="footeralpha">GREPLE GMBH <br> benno-strauss-str. 7b | 90763 <br> +4915124128132<br> hello@greple.de</p>
		</div>
      <div class="footertexttwo">
			<p class="footerbeta">RECHTLICHE HINWEISE<br></p>
			<a class="footer" href="https://greple.de/impressum/">Impressum<br></a>
			<a class="footer" href="https://greple.de/datenschutzerklaerung/">Dateschutz</a>
			</div>
				<div class ="footerpic">
				  <img class="footerpic" src="greple.png" alt="Greple GMBH" style="width:320px;height:160px;">
				</div>
			
	
	</div>
</footer>

</body>
</html>
