  <?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styleregister.css">
</head>
<body>

<header class="header" id="header">
    <a href="https://greple.de/">
	    <img class="one" src="greple.png" alt="Greple GMBH" style="width:180px;height:100px;"> 
    </a>
</header>

<section class="section">
    <div class="container">
        <form action="/action_page.php">
        <div class="row">
          <div class="col-25">
            <label for="fname">First Name</label>
          </div>
          <div class="col-75">
            <input type="text" id="fname" name="firstname" placeholder="First name..">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="lname">Last Name</label>
          </div>
          <div class="col-75">
            <input type="text" id="lname" name="lastname" placeholder="Last name..">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="gender">Gender</label>
          </div>
          <div class="col-75">
            <select id="gender" name="gender">
              <option value="Male">Male</option>
              <option value="Femal">Femal</option>
              <option value="Undefined">Diverse</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label class="down" for="email">Email</label>
          </div>
          <div class="col-75">
            <input type="text" id="email" name="email" placeholder="insert@email.here">
          </div>
        </div>
        <div class="row">
          <input type="submit" href="login.php" value="Submit">
        </div>
        </form>
      </div>
</section>

<footer>
	<div class="footer">
		<div class="footertext">
		<p class="footeralpha">GREPLE GMBH <br> benno-strauss-str. 7b | 90763 <br> +4915124128132<br> hello@greple.de</p>
		</div>
      <div class="footertexttwo">
			<p class="footerbeta">RECHTLICHE HINWEISE<br></p>
			<a class="footer" href="https://greple.de/impressum/">Impressum<br></a>
			<a class="footer" href="https://greple.de/datenschutzerklaerung/">Dateschutz</a>
			</div>
				<div class ="footerpic">
				  <img class="footerpic" src="greple.png" alt="Greple GMBH" style="width:320px;height:160px;">
				</div>
			
	
	</div>
</footer>

</body>
</html>