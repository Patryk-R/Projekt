<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en-EN">
<head>
	<title>Greple AI login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body> 
<header class="header" id="header">
    <a href="https://greple.de/">
	    <img class="one" src="greple.png" alt="Greple GMBH" style="width:180px;height:100px;"> 
    </a>
</header>

<section class="h1">
  <p class="br"><br></p>
  <h2>Please login...</h2>
  <script type = "text/javascript">
var count = 2;
function validate() {
var un = document.myform.username.value;
var pw = document.myform.pword.value;
var valid = false;
var unArray = ["username1", "username2", "username3", "username4"];  
var pwArray = ["password1", "password2", "password3", "password4"];  
for (var i=0; i <unArray.length; i++) {
if ((un == unArray[i]) && (pw == pwArray[i])) {
valid = true;
break;
}
}
if (valid) {
alert ("Login was sucessfully processed.  You will be redirected to the members page now.");
window.location = "/ai.php";
return false;
}
var t = " tries";
if (count == 1) {t = " try"}
if (count >= 1) {
alert ("Invalid username and/or password.  You have " + count + t + " left.");
document.myform.username.value = "";
document.myform.pword.value = "";
setTimeout("document.myform.username.focus()", 25);
setTimeout("document.myform.username.select()", 25);
count --;
}
else {
alert ("Still incorrect! You have no more tries left!");
document.myform.username.value = "No more tries allowed!";
document.myform.pword.value = "";
document.myform.username.disabled = true;
document.myform.pword.disabled = true;
return false;
}
}
</script>
	<form name = "myform">
	<input placeholder="Enter Username" type="text" name="username" class="input"> 
	<br>
	<input placeholder="Enter Password" type="password" name="pword" class="input">
	<br>
	<input class=login type="button" value="Login" name="Submit" onclick= "validate()">
	<form name = "myform">

</form>
	</div>
</section>

		<aside>
		<div class="backgroundtwo">
   			<img class="backgroundtwo" src="backgroundtwo.png" alt="Greple GMBH">
 		</div>
		</aside>

<footer>
	<div class="footer">
		<div class="footertext">
		<p class="footeralpha">GREPLE GMBH <br> benno-strauss-str. 7b | 90763 <br> +4915124128132<br> hello@greple.de</p>
		</div>
     		<div class="footertexttwo">
				<p class="footerbeta">RECHTLICHE HINWEISE<br></p>
				<a class="footer" href="https://greple.de/impressum/">Impressum<br></a>
				<a class="footer" href="https://greple.de/datenschutzerklaerung/">Dateschutz</a>
			</div>
				<div class ="footerpic">
				  <img class="footerpic" src="greple.png" alt="Greple GMBH" style="width:320px;height:160px;">
				</div>
	</div>
</footer>	

</body>
</html>